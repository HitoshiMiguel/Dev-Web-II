function dividir(a, b)
{
if (b == 0 || a == 0 )
{
    return "Erro";
} 


    return a / b;
}

module.exports = dividir;