function subtrair(a, b)
{
    return a - b;
}

module.exports = subtrair;